import React from "react";
import { Avatar, AvatarImage } from "./ui/avatar";

const BotAvatar = () => {
  return (
    <Avatar className="w-12 h-12">
      <AvatarImage className="p-0" src="/logo2.png" />
    </Avatar>
  );
};

export default BotAvatar;

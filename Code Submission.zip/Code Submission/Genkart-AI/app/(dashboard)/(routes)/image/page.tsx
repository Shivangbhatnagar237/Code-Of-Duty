"use client";

import "./page.css";

import axios from "axios";
import path from "path";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import Heading from "@/components/Heading";
import { ImageIcon, Search, ExternalLink } from "lucide-react";
import { useForm } from "react-hook-form";

import { amountOptions, formSchema, resolutionOptions } from "./constants";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import Empty from "@/components/Empty";
import Loader from "@/components/Loader";
import { cn } from "@/lib/utils";
import UserAvatar from "@/components/User-avatar";
import BotAvatar from "@/components/Bot-avatar";
import { useEffect, useRef, useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardFooter } from "@/components/ui/card";
import Image from "next/image";
import { ChatCompletionRequestMessage } from "openai";

import { Typewriter } from "react-simple-typewriter";

const ImagePage = () => {
  const router = useRouter();
  const [images, setImages] = useState<string[]>([]);
  const [previous, setPrevious] = useState("");

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      prompt: "",
      amount: "1",
      resolution: "1024x1024",
    },
  });

  // const isLoading = form.formState.isSubmitting;
  const [isLoading, setIsLoading] = useState(false);

  const typeCont = useRef(null);

  // Message for the User
  const [statusMessage, setStatusMessage] = useState("");
  const [arr, setArr] = useState<string[]>([]);

  const onAskSubmit = async (values: z.infer<typeof formSchema>) => {
    try {
      setIsLoading(true);
      setStatusMessage("Processing your request...");
      setImages([]); // empty previous generated images with new from submit

      // typewriter code
      // const typewriter = typeCont.current;
      // console.log(typewriter);

      // if (typewriter) type(typewriter);

      // return;
      console.log("Previous value: " + JSON.stringify(values));

      setPrevious(""); // reset all previous queries
      const userMessage: ChatCompletionRequestMessage = {
        role: "user",
        content: values.prompt,
      };
      const modifiedQueryResponse = await axios.post("/api/conversation", {
        messages: [userMessage],
      });

      const modifiedQuery = modifiedQueryResponse.data;
      modifiedQuery.content = modifiedQuery.content.replaceAll('"', "");
      setPrevious(modifiedQuery.content);
      console.log("mq " + JSON.stringify(modifiedQuery));
      values.prompt = modifiedQuery.content;

      setStatusMessage(
        `Generating AI-powered image matching ${values.prompt}...`
      );

      console.log("Updated value: " + JSON.stringify(values));

      const response = await axios.post("/api/image", values);
      // return;
      console.log("Response:", response);

      // wsdfghjm
      // const urls = response.data.map((image: { url: string }) => image.url);
      const url = response.data[0].url;
      console.log(url + " fronrend");

      setStatusMessage(`Getting similar outfit recommendations...`);

      const relatedImages = await axios.post("http://localhost:5000/users", {
        url: url,
      });

      console.log(relatedImages.data.res);

      setIsLoading(false);
      setImages(relatedImages.data.res);
      setStatusMessage(
        `Personalised outfit recommendations for ${values.prompt}`
      );

      // form.reset();
    } catch (error) {
      // TODO: Open Pro Model
      console.log(error);
    } finally {
      router.refresh();
    }
  };

  useEffect(() => {
    setArr([statusMessage]);
  }, [statusMessage]);

  const onUpdateSubmit = async (values: z.infer<typeof formSchema>) => {
    try {
      setIsLoading(true);
      setStatusMessage("Processing your request...");

      setImages([]); // empty previous generated images with new from submit

      values.prompt = previous + " " + values.prompt;

      console.log("Previous value: " + JSON.stringify(values));

      const userMessage: ChatCompletionRequestMessage = {
        role: "user",
        content: values.prompt,
      };
      const modifiedQueryResponse = await axios.post("/api/conversation", {
        messages: [userMessage],
      });

      const modifiedQuery = modifiedQueryResponse.data;
      modifiedQuery.content = modifiedQuery.content.replaceAll('"', "");
      setPrevious(modifiedQuery.content);
      console.log("mq " + JSON.stringify(modifiedQuery));
      values.prompt = modifiedQuery.content;

      setStatusMessage(`Updating image for ${values.prompt}...`);

      console.log("Updated value: " + JSON.stringify(values));

      const response = await axios.post("/api/image", values);
      // return;
      console.log("Response:", response);

      // wsdfghjm
      // const urls = response.data.map((image: { url: string }) => image.url);
      const url = response.data[0].url;
      console.log(url + " fronrend");

      setStatusMessage(`Getting similar outfit recommendations...`);

      const relatedImages = await axios.post("http://localhost:5000/users", {
        url: url,
      });

      console.log(relatedImages.data.res);

      setIsLoading(false);
      setImages(relatedImages.data.res);

      setStatusMessage(
        `Personalised outfit recommendations for ${values.prompt}`
      );

      // form.reset();
    } catch (error) {
      // TODO: Open Pro Model
      console.log(error);
    } finally {
      router.refresh();
    }
  };

  // useEffect(() => {
  //   if (typeCont.current) type(typeCont.current);
  // }, [typeCont]);

  // typewriter code
  // const text =
  //   "This is a ChatGPT-like typing effect, simulating human typing with random delays and a blinking cursor. It also supports multiline text and ensures the cursor is displayed at the end of the last output character.";
  // let index = 0;
  // const type = (typewriter: HTMLElement) => {
  //   console.log(typewriter);
  //   if (typewriter){
  //     if (index < text.length) {
  //       typewriter.innerHTML =
  //         text.slice(0, index) + '<span class="blinking-cursor">|</span>';
  //       index++;
  //       setTimeout(type, Math.random() * 150 + 50);
  //     } else {
  //       typewriter.innerHTML =
  //         text.slice(0, index) + '<span class="blinking-cursor">|</span>';
  //     }
  //   }
  // };

  // function type(typewriter: HTMLElement) :void {
  //   if (index < text.length) {
  //     typewriter.innerHTML =
  //       text.slice(0, index) + '<span class="blinking-cursor">|</span>';
  //     index++;
  //     setTimeout(type, Math.random() * 150 + 50);
  //   } else {
  //     typewriter.innerHTML =
  //       text.slice(0, index) + '<span class="blinking-cursor">|</span>';
  //   }
  // }

  return (
    <div>
      <Heading
        title="Generative AI Search"
        description="Start shopping using your prompt!"
        icon={Search}
        iconColor="text-pink-700"
        bgColor="bg-pink-700/10"
      />
      {/* <Typewriter words={["Shivang"]} cursor={true} /> */}
      <div className="px-4 lg:px-8">
        {/* Status Message for the User */}
        {statusMessage.length > 0 && (
          <div
            className="p-4 w-full flex items-start gap-x-0 rounded-lg user items-center  bg-muted"
            style={{
              width: "99%",
            }}
          >
            <BotAvatar />
            {/* <p className="text-sm" ref={typeCont}>
              {statusMessage}
            </p> */}
            <Typewriter
              key={arr.join(",")}
              words={arr}
              cursor={true}
              typeSpeed={50}
            />
          </div>
        )}

        <div
          style={{
            position: "fixed",
            bottom: "30px",
            left: "60%",
            width: "74%",
            transform: "translateX(-50%)",
          }}
        >
          <Form {...form}>
            <div className="w-full flex items-center content-between rounded-lg border p-4 px-3 md:px-6 focus-within:shadow-sm gap-4">
              <form
                // onSubmit={form.handleSubmit(onSubmit)}
                className="w-full grid grid-cols-6 gap-2"
              >
                <FormField
                  name="prompt"
                  render={({ field }) => (
                    <FormItem className="col-span-12 lg:col-span-6">
                      {/* <FormLabel /> */}
                      <FormControl className="m-0 p-0">
                        <Input
                          className="border-0 outline-none focus-visible:ring-0 focus-visible:ring-transparent px-1"
                          disabled={isLoading}
                          placeholder="Some suit options for bachelor party"
                          {...field}
                        />
                      </FormControl>
                      {/* <FormDescription /> */}
                      {/* <FormMessage /> */}
                    </FormItem>
                  )}
                />
                {/* <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem className="col-span-12 lg:col-span-2">
                    <Select
                      disabled={isLoading}
                      onValueChange={field.onChange}
                      value={field.value}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue defaultValue={field.value} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {amountOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              /> */}
                {/* <FormField
                control={form.control}
                name="resolution"
                render={({ field }) => (
                  <FormItem className="col-span-12 lg:col-span-2">
                    <Select
                      disabled={isLoading}
                      onValueChange={field.onChange}
                      value={field.value}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue defaultValue={field.value} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {resolutionOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              /> */}
              </form>
              <div className="flex gap-4">
                <Button
                  // onSubmit={form.handleSubmit(onSubmit)}
                  onClick={() => onAskSubmit(form.getValues())}
                  className="col-span-12 lg:col-span-2 w-full px-8 bg-[#292a2d]"
                  disabled={isLoading}
                >
                  Generate
                </Button>
                {previous.trim().length > 0 && (
                  <Button
                    onClick={() => onUpdateSubmit(form.getValues())}
                    className="col-span-12 lg:col-span-2 w-full px-8 bg-[#292a2d]"
                    disabled={isLoading}
                  >
                    Update
                  </Button>
                )}
              </div>
            </div>
          </Form>
        </div>
        <div className="space-y-4 mt-4">
          {isLoading && (
            <div
              className="p-8 rounded-lg w-full flex items-center justify-center"
              // style={{ marginTop: "-3rem" }}
            >
              <Loader />
            </div>
          )}

          {images.length === 0 && !isLoading && (
            <Empty label="Start generating images by your prompt!" />
          )}

          <div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mt-8"
            // style={{ height: images.length > 0 ? "24rem" : "0rem" }}
          >
            {images.map((src) => (
              <Card key={src} className="rounded-lg overflow-hidden">
                <div
                  className="relative aspect-square"
                  // style={{ alignSelf: "center" }}
                >
                  <Image
                    alt="Image"
                    fill
                    src={`http://localhost/${src.substring(7)}`}
                  />
                </div>
                <CardFooter className="p-2">
                  <Button
                    onClick={() =>
                      window.open(`http://localhost/${src.substring(7)}`)
                    }
                    variant="secondary"
                    className="w-full"
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Explore
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImagePage;

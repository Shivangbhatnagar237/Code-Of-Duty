const express = require("express");
const path = require("path");
const app = express();

app.get("/:file", (req, res) => {
  console.log(path.join(__dirname, "../fashion-recommender-system/images"));
  return res.sendFile(
    path.join(
      __dirname,
      "../fashion-recommender-system/images",
      req.params.file
    )
  );
});

app.listen(80, () => {
  console.log("server started");
});

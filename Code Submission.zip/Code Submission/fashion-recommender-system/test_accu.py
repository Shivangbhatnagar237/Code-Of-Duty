import pickle
from annoy import AnnoyIndex
import numpy as np
from sklearn.metrics import precision_score, recall_score, f1_score, average_precision_score
from tensorflow.keras.applications.resnet50 import ResNet50, preprocess_input
from tensorflow.keras.preprocessing import image
from numpy.linalg import norm

# Load feature embeddings, filenames, and ground truth data
feature_list = np.array(pickle.load(open('embeddings_1.pkl', 'rb')))
filenames = pickle.load(open('filenames_1.pkl', 'rb'))

model = ResNet50(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
model.trainable = False

# Load or create the Annoy index
annoy_index = AnnoyIndex(feature_list.shape[1], metric='euclidean')
for idx, feature_vector in enumerate(feature_list):
    annoy_index.add_item(idx, feature_vector)
annoy_index.build(10)  # Number of trees in the index

# Prepare ground truth data (sample, adjust as needed)
ground_truth = {
    'sample/10003.jpeg': ['images/10541.jpeg', 'images/54559.jpg', 'images/1121.jpeg', 'images/5237.jpeg',
                          'images/2938.jpeg'],
    'sample/10019.png': ['images/image22065.jpg', 'images/VE022S01Z-N11@8.1.jpg', 'images/EV421J05J-Q11@18.jpg',
                         'images/MQ122S00B-Q11@10.jpg', 'images/PE121J03K-Q11@12.jpg'],
    'sample/10006.jpg': ['images/MOM22O06U-Q11@1.1.jpg', 'images/MOM22O0AN-Q11@2.1.jpg', 'images/MOM22O08D-Q11@2.1.jpg',
                         'images/MOM22O09U-Q11@2.1.jpg', 'images/MOM22O05G-Q11@1.1.jpg'],
}

# Testing
precision_scores = []
recall_scores = []
f1_scores = []
average_precisions = []

for query_image, similar_images in ground_truth.items():
    # Load and preprocess query image
    img = image.load_img(query_image, target_size=(224, 224))
    img_array = image.img_to_array(img)
    expanded_img_array = np.expand_dims(img_array, axis=0)
    preprocessed_query_img = preprocess_input(expanded_img_array)

    # Extract features from the query image
    query_features = model.predict(preprocessed_query_img)


    # Flatten the query features and normalize
    query_features_flatten = query_features.flatten()
    normalized_query_features = query_features_flatten / np.linalg.norm(query_features_flatten)
    print(normalized_query_features.shape)

    # Perform nearest neighbors search
    num_neighbors = len(similar_images)  # Number of similar images in ground truth
    retrieved_indices = annoy_index.get_nns_by_vector(normalized_query_features, num_neighbors)

    # Convert retrieved indices to filenames
    retrieved_filenames = [filenames[idx] for idx in retrieved_indices]

    # Calculate metrics
    precision = precision_score(similar_images, retrieved_filenames, average='micro')
    recall = recall_score(similar_images, retrieved_filenames, average='micro')
    f1 = f1_score(similar_images, retrieved_filenames, average='micro')
    avg_precision = average_precision_score(similar_images, retrieved_filenames, average='micro')

    precision_scores.append(precision)
    recall_scores.append(recall)
    f1_scores.append(f1)
    average_precisions.append(avg_precision)

# Calculate mean scores over all test queries
mean_precision = np.mean(precision_scores)
mean_recall = np.mean(recall_scores)
mean_f1 = np.mean(f1_scores)
mean_avg_precision = np.mean(average_precisions)

# Print results
print(f"Mean Precision: {mean_precision:.4f}")
print(f"Mean Recall: {mean_recall:.4f}")
print(f"Mean F1-Score: {mean_f1:.4f}")
print(f"Mean Average Precision: {mean_avg_precision:.4f}")

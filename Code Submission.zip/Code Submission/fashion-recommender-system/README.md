# fashion-recommender-system
A Deep Learning based Fashion Recommender System using the ResNET50

from flask import Flask, jsonify, request

app = Flask(__name__)

# Sample data
users = [
    {"id": 1, "name": "Alice"},
    {"id": 2, "name": "Bob"},
    {"id": 3, "name": "Charlie"}
]

# Route to get all users
# @app.route('/users', methods=['GET'])
# def get_users():
#     return jsonify(users)

# Route to get a specific user by ID
@app.route('/users', methods=['POST'])
def get_user():
    # user = next((user for user in users if user["id"] == user_id), None)
    # if user:
    #     return jsonify(user)
    # else:
    #     return jsonify({"message": "User not found"}), 404
    body = request.get_json()
    return jsonify(body)

if __name__ == '__main__':
    app.run(debug=True)
import pickle
import numpy as np
from numpy.linalg import norm
from tensorflow.keras.preprocessing import image
from tensorflow.keras.layers import GlobalMaxPooling2D
from tensorflow.keras.applications.resnet50 import ResNet50, preprocess_input
import cv2
import matplotlib.pyplot as plt
import tensorflow
from annoy import AnnoyIndex

import requests
from PIL import Image
from io import BytesIO

# import Flask
from flask import Flask, jsonify, request
from flask_cors import CORS, cross_origin
from flask_restful.utils import cors
from flask_restful import Api
# from flask_cors import cross_origin

app = Flask(__name__)

# CORS(app)
# CORS(app, resources={r"/users": {"origins": "http://localhost:3000"}})

@app.route('/users', methods=['POST'])
def get_user():
    body = request.get_json()
    print(body["url"])
    url = body["url"]
    # url = "https://i.pinimg.com/originals/b6/9c/b4/b69cb48adb88f3f39a6d6d0e4c7ae375.jpg"
    res  = requests.get(url)
    img_data = res.content

    # Load feature embeddings and filenames
    feature_list = np.array(pickle.load(open('embeddings_1.pkl', 'rb')))
    filenames = pickle.load(open('filenames_1.pkl', 'rb'))

    # Load and preprocess query image
    # query_img = image.load_img('./sample/10003.jpeg', target_size=(224, 224))
    query_img = Image.open(BytesIO(img_data)).resize((224,224))
    print(query_img)
    query_img_array = image.img_to_array(query_img)
    expanded_query_img_array = np.expand_dims(query_img_array, axis=0)
    preprocessed_query_img = preprocess_input(expanded_query_img_array)

    # Load or create the ResNet50 model
    model = ResNet50(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
    model.trainable = False

    model = tensorflow.keras.Sequential([
        model,
        GlobalMaxPooling2D()
    ])

    # Extract features from the query image
    query_features = model.predict(preprocessed_query_img).flatten()
    normalized_query_features = query_features / norm(query_features)

    # Build Annoy index
    annoy_index = AnnoyIndex(normalized_query_features.shape[0], metric='euclidean')
    for idx, feature_vector in enumerate(feature_list):
        annoy_index.add_item(idx, feature_vector)
    annoy_index.build(10)  # Number of trees in the index

    # Perform nearest neighbors search
    num_neighbors = 5
    nearest_indices = annoy_index.get_nns_by_vector(normalized_query_features, num_neighbors)

    # Visualize similar images
    # plt.figure(figsize=(15, 8))

    resList = []
    for idx, file_idx in enumerate(nearest_indices[1:], start=1):
        similar_img = cv2.imread(filenames[file_idx])
        print(filenames[file_idx])
        resList.append(filenames[file_idx])
        similar_img = cv2.cvtColor(similar_img, cv2.COLOR_BGR2RGB)

        # plt.subplot(1, num_neighbors - 1, idx)
        # plt.imshow(similar_img)
        # plt.title(f"Similar {idx}")
        # plt.axis('off')

    # plt.tight_layout()
    # plt.show()

    ret = jsonify({"res": resList})
    ret.headers.add('Access-Control-Allow-Origin', '*')
    return ret
# @cross_origin(origins="http://localhost:3000")

if __name__ == '__main__':
    app.run(debug=True)